O projeto é sobre uma hamburgueria gourmet criado em react.


O projeto foi feito utilizand essas bibliotecas.

 "@testing-library/jest-dom": "^5.11.4",
    "@testing-library/react": "^11.1.0",
    "@testing-library/user-event": "^12.1.10",
    "axios": "^1.2.1",
    "json-server": "^0.17.1",
    "react": "^17.0.2",
    "react-dom": "^17.0.2",
    "react-icons": "^4.3.1",
    "react-scripts": "4.0.3",
    "scrollreveal": "^4.0.9",
    "styled-components": "^5.3.3",
    "web-vitals": "^1.0.1"
    "react-router-dom": "^6.4.5",
