import React from 'react'
import Form from './Form'
import Footer from './Footer'
import Hero from './Hero'
import Navbar from './Navbar'
import Portfolio from './Portfolio'
import Products from './Products'
import ScrollToTop from './ScrollToTop'
import Services from './Services'

function Rotas() {
  return (
    <>
    <Navbar/>
    <Hero/>
    <ScrollToTop/>
    <Services/>
    <Portfolio/>
    <Products/>
    <Form/>
    <Footer/>
    </>
  )
}

export default Rotas