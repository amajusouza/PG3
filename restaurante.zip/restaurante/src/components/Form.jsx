import React, { useState } from 'react';
import "./Form.css";
import axios from "axios";

function Form() {


    const [inputModificar, setInputModificar] = useState("");
    const [inputModificarId, setInputModificarId] = useState("");

    const [inputDeletar, setInputDeletar] = useState("");
    const [inputDeletarId, setInputDeletarId] = useState("");

    const [inputNome, setInputNome] = useState("");
    const [inputEmail, setInputEmail] = useState("");
    const [inputComentario, setInputComentario] = useState("");

    const enviarValoresPost = () => {
        axios.post("http://localhost:3000/contatos", { nome: inputNome, email: inputEmail, comentario: inputComentario }).then().catch((error) => console.log(error));
    }

    const enviarValoresPut = () => {
        axios.put("http://localhost:3000/contatos/" + inputModificarId, { nome: "" }  ).then().catch((error) => console.log(error));
    }

    const enviarValoresDelete = () => {
        axios.put("http://localhost:3000/contatos/" + inputDeletarId, { nome: "" }  ).then().catch((error) => console.log(error));
    }


    const handleInputName = (e) => {
        setInputNome(e.target.value)
    }

    const handleInputEmail = (e) => {
        setInputEmail(e.target.value)
    }

    const handleInputComentario = (e) => {
        setInputComentario(e.target.value)
    }

    const handleInputModificar = (e) => {
        setInputModificar(e.target.value)
        console.log(inputModificar)
    }

    const handleInputModificarId = (e) => {
        setInputModificarId(e.target.value)
        console.log(inputModificarId)
    }

    const handleInputDeletar = (e) => {
        setInputDeletar(e.target.value)
    }

    const handleInputDeletarId = (e) => {
        setInputDeletarId(e.target.value)
    }

  return (
    <div>
    <div class="wrapper">
            <div class="box-wrapper">
            <div class="box">
            <h2>Contatos</h2> 
                <form id="form" action="">
                <div>
                    <input onChange={(e) => handleInputName(e)} type="text" name="" id="name" required placeholder=""/>
                    <label>Nome: </label>
                </div>
                <div>
                    <input onChange={(e) => handleInputEmail(e)} type="email" name="" required placeholder=" " pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"/>
                    <label>E-mail </label>
                </div>
                <div>
                    <textarea onChange={(e) => handleInputComentario(e)} required placeholder=" "></textarea>
                    <label>Mensagem</label>
                </div>
                <input onClick={() => enviarValoresPost()} id="submit" type="submit" value="Enviar"/>
                </form>  
        </div>
            </div>

            <div class="box-wrapper">
            <div class="box">
            <h2>Tabela de Admin Para Modificar Nome</h2> 
                <form id="form" action="">
                <div>
                    <input onChange={(e) => handleInputModificar(e)} type="text" name="" id="name" required placeholder=""/>
                    <label>Modificar</label>
                </div>
                <div>
                    <input onChange={(e) => handleInputModificarId(e)} type="text" name="" id="name" required placeholder=""/>
                    <label>ID</label>
                </div>
                <input onSubmit={() => enviarValoresPut()} id="submit" type="submit" value="Enviar"/>
                </form>  
        </div>
            </div>

            <div class="box-wrapper">
            <div class="box">
            <h2>Tabela de Admin Para Deletar Nome</h2> 
                <form id="form" action="">
                <div>
                    <input onChange={(e) => handleInputDeletar(e)} type="text" name="" id="name" required placeholder=""/>
                    <label>Modificar</label>
                </div>
                <div>
                    <input onChange={(e) => handleInputDeletarId(e)} type="text" name="" id="name" required placeholder=""/>
                    <label>ID</label>
                </div>
                <input onSubmit={() => enviarValoresDelete()} id="submit" type="submit" value="Enviar"/>
                </form>  
        </div>
            </div>
        </div>
    </div>
  )
}

export default Form
