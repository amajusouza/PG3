import React, { useEffect } from "react";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Navbar from "./components/Navbar";
import Newsletter from "./components/Newsletter";
import Portfolio from "./components/Portfolio";
import Products from "./components/Products";
import ScrollToTop from "./components/ScrollToTop";
import Services from "./components/Services";
import scrollreveal from "scrollreveal";
import Form from "./components/Form";
import { BrowserRouter, BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Rotas from "./components/Rotas";

export default function App() {
  useEffect(() => {
    const sr = scrollreveal({
      origin: "top",
      distance: "80px",
      duration: 2000,
      reset: false,
    });
    sr.reveal(
      `
        nav,
        #home,
        #services,
        #portfolio,
        #testimonials,
        #products,
        #newsletter,
        .footer
    `,
      {
        opacity: 0,
        interval: 200,
      }
    );
  }, []);
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index path="/" element={<Rotas/>}/>
          <Route path="/scrolltotop" element={<ScrollToTop/>}/>
          <Route path="/hero" element={<Hero/>}/>
          <Route path="/Services" element={<Services/>}/>
          <Route path="/Portfolio" element={<Portfolio/>}/>
          <Route path="/Products" element={<Products/>}/>
          <Route path="/hero" element={<Form/>}/>
          <Route path="/Footer" element={<Footer/>}/>
        </Routes>
      </BrowserRouter>
    </>
  );
}
